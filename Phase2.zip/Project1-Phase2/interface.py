from neo4j import GraphDatabase
import pandas as pd

class Neo4jInterface:
    def __init__(self):
        self.driver = GraphDatabase.driver(
            "bolt://localhost:7687",
            auth=("neo4j", "project1phase2")
        )
    
    def close(self):
        self.driver.close()
    
    def run_pagerank(self, max_iterations=20, damping_factor=0.85):
        query = """
        CALL gds.pageRank.write({
            nodeProjection: ['Pickup', 'Dropoff'],
            relationshipProjection: {
                TRIP: {
                    type: 'TRIP',
                    orientation: 'NATURAL',
                    properties: 'fare'
                }
            },
            writeProperty: 'pagerank',
            maxIterations: $max_iterations,
            dampingFactor: $damping_factor
        })
        YIELD nodePropertiesWritten, ranIterations
        RETURN nodePropertiesWritten, ranIterations
        """
        with self.driver.session() as session:
            result = session.run(query, max_iterations=max_iterations, damping_factor=damping_factor)
            return pd.DataFrame([dict(record) for record in result])
    
    def run_bfs(self, start_node_id, depth=3):
        query = """
        MATCH (start:Pickup {id: $start_node_id})
        CALL gds.bfs.stream({
            nodeProjection: ['Pickup', 'Dropoff'],
            relationshipProjection: {
                TRIP: {
                    type: 'TRIP',
                    orientation: 'NATURAL'
                }
            },
            startNode: start,
            maxDepth: $depth
        })
        YIELD path
        RETURN path
        """
        with self.driver.session() as session:
            result = session.run(query, start_node_id=start_node_id, depth=depth)
            return pd.DataFrame([dict(record) for record in result])
    
    def get_trip_stats(self):
        query = """
        MATCH (p:Pickup)-[t:TRIP]->(d:Dropoff)
        RETURN p.id AS pickup_id, d.id AS dropoff_id, 
               avg(t.distance) AS avg_distance, 
               avg(t.fare) AS avg_fare,
               count(*) AS trip_count
        ORDER BY trip_count DESC
        LIMIT 10
        """
        with self.driver.session() as session:
            result = session.run(query)
            return pd.DataFrame([dict(record) for record in result])

if __name__ == "__main__":
    interface = Neo4jInterface()
    
    print("Running PageRank...")
    print(interface.run_pagerank())
    
    print("\nRunning BFS from location 3...")
    print(interface.run_bfs(3))
    
    print("\nTop trip routes:")
    print(interface.get_trip_stats())
    
    interface.close()