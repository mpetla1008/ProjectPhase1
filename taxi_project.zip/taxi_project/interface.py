from neo4j import GraphDatabase

class GraphAlgorithms:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password), encrypted=False)
        self.driver.verify_connectivity()

    def close(self):
        self.driver.close()

    def run_pagerank(self, max_iter, weight_property):
        with self.driver.session() as session:
            # Drop any existing graph projection
            session.run("CALL gds.graph.drop('tripGraph', false) YIELD graphName")
            # Create a graph projection
            session.run("""
                CALL gds.graph.project(
                    'tripGraph',
                    'Location',
                    'TRIP',
                    { relationshipProperties: $weight_property }
                )
            """, weight_property=weight_property)

            # Run PageRank
            result = session.run("""
                CALL gds.pageRank.stream('tripGraph', {
                    maxIterations: $max_iter,
                    dampingFactor: 0.85,
                    relationshipWeightProperty: $weight_property
                })
                YIELD nodeId, score
                RETURN gds.util.asNode(nodeId).name AS location, score
                ORDER BY score DESC
            """, max_iter=max_iter, weight_property=weight_property)

            scores = [(record["location"], record["score"]) for record in result]
            if not scores:
                return None, None
            max_pr = scores[0]
            min_pr = scores[-1]
            return max_pr, min_pr

    def run_bfs(self, start_node, target_nodes):
        with self.driver.session() as session:
            # Drop any existing graph projection
            session.run("CALL gds.graph.drop('tripGraph', false) YIELD graphName")
            # Create a graph projection
            session.run("""
                CALL gds.graph.project(
                    'tripGraph',
                    'Location',
                    'TRIP'
                )
            """)

            # Get node IDs for start_node and target_nodes
            start_node_id = session.run(
                "MATCH (n:Location {name: $name}) RETURN id(n) AS id",
                name=start_node
            ).single()["id"]
            target_node_ids = [
                record["id"] for record in session.run(
                    "MATCH (n:Location) WHERE n.name IN $names RETURN id(n) AS id",
                    names=target_nodes
                )
            ]

            # Run BFS
            result = session.run("""
                CALL gds.bfs.stream('tripGraph', {
                    sourceNode: $start_node_id,
                    targetNodes: $target_node_ids
                })
                YIELD path
                RETURN [node in nodes(path) | node.name] AS path
            """, start_node_id=start_node_id, target_node_ids=target_node_ids)

            paths = [record["path"] for record in result]
            return paths

def main():
    algo = GraphAlgorithms("bolt://localhost:7687", "neo4j", "project1phase1")
    
    # Run PageRank
    max_pr, min_pr = algo.run_pagerank(max_iter=20, weight_property="distance")
    print("PageRank Results:")
    print(f"Max PageRank: Location {max_pr[0]} with score {max_pr[1]}")
    print(f"Min PageRank: Location {min_pr[0]} with score {min_pr[1]}")
    
    # Run BFS
    start_node = 3
    target_nodes = [18, 20, 31]
    paths = algo.run_bfs(start_node, target_nodes)
    print("\nBFS Results:")
    for i, path in enumerate(paths):
        print(f"Path {i+1}: {path}")
    
    algo.close()

if __name__ == "__main__":
    main()