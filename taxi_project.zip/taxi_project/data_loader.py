import pandas as pd
from neo4j import GraphDatabase

class DataLoader:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password), encrypted=False)
        self.driver.verify_connectivity()

    def close(self):
        self.driver.close()

    def load_transform_file(self, file_path):
        # Read the parquet file
        df = pd.read_parquet(file_path)

        # Clean and filter the data (example filters from the PDF context)
        df = df[df["trip_distance"] > 0.1]
        df = df[df["fare_amount"] > 2.5]
        # Filter for Bronx location IDs (example IDs: 3, 18, 20, 31, etc.)
        bronx_locations = [3, 18, 20, 31, 32, 46, 47, 49, 55, 56, 57, 58, 59, 60, 61, 62, 65, 82, 83, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120]
        df = df[df["PULocationID"].isin(bronx_locations) & df["DOLocationID"].isin(bronx_locations)]

        # Load data into Neo4j
        with self.driver.session() as session:
            for _, row in df.iterrows():
                # Create Location nodes
                session.run("MERGE (p:Location {name: $pu_id})", pu_id=int(row["PULocationID"]))
                session.run("MERGE (d:Location {name: $do_id})", do_id=int(row["DOLocationID"]))
                # Create TRIP relationships
                session.run("""
                    MATCH (p:Location {name: $pu_id}), (d:Location {name: $do_id})
                    CREATE (p)-[:TRIP {distance: $dist, fare: $fare, pickup_dt: $pu_dt, dropoff_dt: $do_dt}]->(d)
                """, pu_id=int(row["PULocationID"]), do_id=int(row["DOLocationID"]),
                    dist=float(row["trip_distance"]), fare=float(row["fare_amount"]),
                    pu_dt=str(row["tpep_pickup_datetime"]), do_dt=str(row["tpep_dropoff_datetime"]))

def main():
    data_loader = DataLoader("bolt://localhost:7687", "neo4j", "project1phase1")
    data_loader.load_transform_file("/var/lib/neo4j/import/yellow_tripdata_2022-03.parquet")
    data_loader.close()

if __name__ == "__main__":
    main()